# MIC-seq analysis workflow
The human microbiome is made up of huge amount of microbes in the gastrointestinal tract and has significant links to various human health conditions.
We developed a computational pipeline named MIC-seq analysis workflow for single-microbe RNA sequencing of human gut microbiome. Our pipeline has three major modules: MIC-Anno, MIC-Bac and MIC-Phage. The main function of MIC-Anno is processing taxonomic annotation for each microbe.Based on the results of MIC-Anno, we can use MIC-Bac and MIC-Phage to construct bacteria and phage transcriptional matrix.
