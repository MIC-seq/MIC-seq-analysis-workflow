from __future__ import absolute_import 

from MICtools.version import __version__
